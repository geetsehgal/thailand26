const S={g(k,d){try{return JSON.parse(localStorage.getItem('th26'+k))??d}catch(e){return d}},s(k,v){try{localStorage.setItem('th26'+k,JSON.stringify(v))}catch(e){}}};
const $=(s,r=document)=>r.querySelector(s),bar=(p,c)=>`<div class="bar"><i style="width:${Math.min(100,p)}%;${c?'background:'+c:''}"></i></div>`;
const today=()=>{const n=new Date(),d=Math.round((new Date(n.getFullYear(),n.getMonth(),n.getDate())-new Date(2026,11,8))/864e5);return d>=0&&d<7?d:-1};
const C=S.g('c',{});
function wire(cb){document.querySelectorAll('input[data-k]').forEach(i=>{i.checked=!!C[i.dataset.k];i.onchange=()=>{C[i.dataset.k]=i.checked;S.s('c',C);cb()}});cb()}
document.body.insertAdjacentHTML('afterbegin','<nav>'+[['index.html','🗓 Itinerary'],['food.html','🍗 Food'],['photos.html','📸 Photos']].map(([h,t])=>`<a href="${h}" class="${location.pathname.endsWith(h)||(h=='index.html'&&location.pathname.endsWith('/'))?'on':''}">${t}</a>`).join('')+'</nav>');
const J=S.g('j',0),X=s=>s.replace(/\{([^|}]*)\|([^}]*)\}/g,(_,a,b)=>J?a:b);
$('main').insertAdjacentHTML('afterbegin',`<label class="card" style="display:flex;gap:10px;align-items:center"><input type="checkbox" style="width:20px;height:20px;accent-color:var(--ok)" ${J?'checked':''} onchange="S.s('j',this.checked?1:0);location.reload()"><span><b>Third friend joining from Dec 12</b><br><span class="mut">Off by default: the plan is for 2 guys all week</span></span></label>`);
